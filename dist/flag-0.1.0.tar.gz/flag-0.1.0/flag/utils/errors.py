class LexicalException(Exception):
    pass


class SyntaxException(Exception):
    pass
